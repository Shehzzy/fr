import * as app_constant from './app_constant';
import connect_to_db from './connect_db';
import bootstrap_data from './error_msg';


export {
      connect_to_db,
      bootstrap_data,
      app_constant,
}

//https://www.figma.com/design/rBXijQA6LzeRGL40cymukq/Elliott?node-id=0-1&p=f&t=2CGXC8TXyJB5nJoV-0

//https://we.tl/t-uquUOOUZY9